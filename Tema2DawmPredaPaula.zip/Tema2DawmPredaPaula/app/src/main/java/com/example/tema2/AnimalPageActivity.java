package com.example.tema2;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tema2.adapter.AnimalAdapter;
import com.example.tema2.model.AnimalModel;

import java.util.ArrayList;

public class AnimalPageActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private EditText editText1;
    private EditText editText2;
    private Button addButton;
    private TextView errorMessage;
    private AnimalAdapter adapter;
    private ArrayList<AnimalModel> arrayList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_animal);
        recyclerView = findViewById(R.id.recycler_view);
        editText1 = findViewById(R.id.AddAnimalName);
        editText2 = findViewById(R.id.AddAnimalContinent);
        addButton = findViewById(R.id.addButton);
        errorMessage= findViewById(R.id.ErrorMessage);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        adapter = new AnimalAdapter(arrayList);
        recyclerView.setAdapter(adapter);
        getSupportActionBar().hide();
        addButton.setOnClickListener(v -> AddItem());
        adapter.setOnItemClickListener(position -> {
            arrayList.remove(position);
            adapter.notifyItemRemoved(position);
        });
    }

    public void AddItem() {
        String name = editText1.getText().toString().trim();
        String continent = editText2.getText().toString().trim();

        if (name.isEmpty()) {
            errorMessage.setText("Add name for animal");
        } else if (continent.isEmpty()) {
            errorMessage.setText("Select continent for animal");
        } else {
            boolean animalExists = false;

            for (AnimalModel animal : arrayList) {
                if (animal.getName().equals(name)) {
                    animalExists = true;
                    errorMessage.setText("Animal is already in list");
                    break;
                }
            }

            if (!animalExists) {
                AnimalModel animalModel = new AnimalModel(name, continent);
                arrayList.add(animalModel);
                int position = arrayList.indexOf(animalModel);
                adapter.notifyItemInserted(position);
                editText1.setText("");
                editText2.setText("");
                errorMessage.setText("");
            }
        }
    }
}
