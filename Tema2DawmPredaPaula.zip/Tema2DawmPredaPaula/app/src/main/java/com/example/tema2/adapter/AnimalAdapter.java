package com.example.tema2.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tema2.R;
import com.example.tema2.model.AnimalModel;

import java.util.ArrayList;

public class AnimalAdapter extends RecyclerView.Adapter<AnimalAdapter.ViewHolder> {

    private ArrayList<AnimalModel> animalList;
    private OnItemClickListener clickListener;

    public AnimalAdapter(ArrayList<AnimalModel> animalList) {
        this.animalList = animalList;
    }

    public interface OnItemClickListener {
        void onItemClick(int position);
    }
    public void setOnItemClickListener(OnItemClickListener listener) {
        this.clickListener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.animal_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        AnimalModel animal = animalList.get(position);
        holder.textViewAnimal.setText(animal.getName());
        holder.textViewContinent.setText(animal.getContinent());
    }

    @Override
    public int getItemCount() {
        return animalList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView textViewAnimal;
        TextView textViewContinent;
        ImageView deleteButton;

        public ViewHolder(View itemView) {
            super(itemView);
            textViewAnimal = itemView.findViewById(R.id.Animal);
            textViewContinent = itemView.findViewById(R.id.Continent);
            deleteButton = itemView.findViewById(R.id.ButtonDelete);
            deleteButton.setOnClickListener(v -> {
                if (clickListener != null) {
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION) {
                        clickListener.onItemClick(position);
                    }
                }
            });
        }
    }
}